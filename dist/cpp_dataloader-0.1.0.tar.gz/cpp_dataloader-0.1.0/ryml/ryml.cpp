#define RYML_SINGLE_HDR_DEFINE_NOW
#include "ryml.hpp"
