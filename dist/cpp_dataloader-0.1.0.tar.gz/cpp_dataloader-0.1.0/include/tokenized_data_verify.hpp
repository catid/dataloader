#pragma once

#include <string>

//------------------------------------------------------------------------------
// Verify

bool VerifyDataset(const std::string& data_folder_path);
